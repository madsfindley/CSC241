package exercises;

public class GraphicObject {
}
