package exercises;

import java.util.Arrays;

public class ExpandableArray {
    private String[] arr;
    private static int DEFAULT_LENGTH = 10;
    private int nrOfElements = 0;

    public ExpandableArray() {
        arr = new String[DEFAULT_LENGTH];
    }

    public boolean add(String s) {
//        where are we putting s?
//        - add at nrOfElements
//        - increment nrOfElements

//        BUT! if nrOfElements == ar.length
//        make a new array (newArr) size: arr.length + arr.length >> 1
//        copy over the elements
//        arr = newArr
//        do our add

        if (nrOfElements == arr.length) {
            String[] newArr = new String[arr.length + arr.length >> 1];
            for (int i = 0; i < arr.length; i++) {
                newArr[i] = arr[i];
            }
            System.arraycopy(arr, 0, newArr, 0, arr.length);
            arr = newArr;
        }
        arr[nrOfElements] = s;
        nrOfElements++;

        return true;
    }
}
