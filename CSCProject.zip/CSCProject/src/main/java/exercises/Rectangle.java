package exercises;

public class Rectangle extends GraphicObject {
}
