package CastleProject;

public class Door {
    private final String name;
    private final String description;
    private String direction;
    private Door other_Room;
    private Room room1;
    private Room room2;
    private boolean isLocked;


    public void setRooms(Room room){
        if (this.room1 == null){
            room1 = room;
        } else {
            room2 = room;
        }
    }

    public void setOther_Room(){
        this.other_Room = other_Room;
    }


    public Door(String name, String description, String direction, Boolean isLocked) {
        this.name = name;
        this.description = description;
        this.direction = direction;
        this.isLocked = isLocked;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void unlock(){
        if(isLocked){
            isLocked = false;
            System.out.println("The door is unlocked. ");
    } else{
            System.out.println("The door is already unlocked.");
        }
    }

    public void lock(){
        if (!isLocked){
            isLocked = true;
            System.out.println("The door is locked.");
        } else {
            System.out.println("The door is already locked. ");
        }
    }

    public String inspectString() {
        return "Door: " + name + "\nDescription: " + description + "\nLocked: " + isLocked;
    }

    @Override
    public String toString() {
        String names = "door " + "direction= " + direction + "\n";
        names += "other_room= " + other_Room + "\n" + "name= " + name + "\n";
        names += "description= " + description + "locked= " + isLocked + "\n";

        return names;
    }
}
