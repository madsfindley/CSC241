package CastleProject;

import CastleProject.Character;

public abstract class NPC extends Character {
    protected String name;
    protected String description;
    public NPC(String name, String description) {
        super(name, description);
        this.name = name;
        this.description = description;
    }

    public String inspectString(){
        return name + description;
    }

    public String toString(){
        return "NPC: " + name + "," + description;
    }
}
