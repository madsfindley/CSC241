package CastleProject;

public interface Inspectable {
    public String inspectString();
}
