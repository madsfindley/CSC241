
package CastleProject;

import java.util.ArrayList;

public class Item implements Inspectable {
    private final String name;
    private final String description;
    private final double weight;
    private final boolean carryable;
    private final boolean hidden;
    private ArrayList<Item> subItems;

    public Item(String name, String description, double weight, boolean carryable, boolean hidden) {
        this.name = name;
        this.description = description;
        this.weight = weight;
        this.carryable = carryable;
        this.hidden = hidden;
        this.subItems = new ArrayList<>();

    }

    public void add(Item subItems){
        subItems.add(subItems);
    }



    @Override
    public String inspectString() {
        return name + ":" + description + ":";
    }

    public String toString(){
        StringBuilder itemInfo = new StringBuilder();
        itemInfo.append("Item: ").append(name).append("\n")
                .append("Description: ").append(description).append("\n")
                .append("Weight: ").append(weight).append("\n")
                .append("Carryable: ").append(carryable).append("\n")
                .append("Hidden: ").append(hidden).append("\n")
                .append("SubItems:\n");
        for (Item subItem : subItems) {
            itemInfo.append(subItem).append("\n");
        }
        return itemInfo.toString();
    }
    }



