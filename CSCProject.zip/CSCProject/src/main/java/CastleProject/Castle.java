package CastleProject;

import java.util.ArrayList;


public class Castle {
    private ArrayList<Room> rooms;
    private ArrayList<Door> doors;
    private ArrayList<Item> items;
    private ArrayList<Character> characters;
    private String qName;


    public Castle(String qName) {
        this.rooms = new ArrayList<>();
        this.doors = new ArrayList<>();
        this.items = new ArrayList<>();
        this.characters = new ArrayList<>();
        this.qName = qName;
    }

    public void addDoor(Door d) {
        doors.add(d);
    }

    public void addCharacter(Character c) {
        characters.add(c);
    }

    public void addItem(Item it) {
        items.add(it);
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public Room findRoomByName(String name) {
        for (Room r : rooms) {
            if (r.getName().equals(name)) {
                return r;
            }
        }
        return null;
    }
}

