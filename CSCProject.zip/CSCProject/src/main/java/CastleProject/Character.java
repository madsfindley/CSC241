package CastleProject;

import CastleProject.Inspectable;
import CastleProject.Room;

public abstract class Character implements Inspectable {
    private final String name;
    private final String description;
    private Room room;

    public Character(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void setRoom(Room r){
        room = r;
    }


    public String inspectString() {
        return "Character: " + name + "\nDescription: " + description;
    }

    public String toString(){
        return name + ", " + description;
    }
}

