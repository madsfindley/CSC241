package CastleProject;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;
    public class XMLHandler extends DefaultHandler {
        private Castle castle;
        private Room currentRoom;
        private Door currentDoor;
        private Player currentPlayer;
        private Item currentItem;
        private Maid currentMaid;
        private Guard currentGuard ;
        private Key currentKey;
        private Room prevRoom;
        private ArrayList<Room> rooms;

        public void startDocument() throws SAXException {
            System.out.println("Document Start");
        }

        public Castle getCastle() {
            return castle;
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            castle = new Castle(qName);
            System.out.println("Start: " + qName);
            if (qName.equals("room")) {
                String name = attributes.getValue("name");
                String description = attributes.getValue("description");
                currentRoom = new Room(name, description);
                castle.addRoom(currentRoom);
                prevRoom = currentRoom;

                System.out.println("Name : " + name);
                System.out.println("Description : " + description);

            }
            if (qName.equals("door")) {
                String name = attributes.getValue("name");
                String description = attributes.getValue("description");
                String direction = attributes.getValue("direction");
                Boolean isLocked = Boolean.parseBoolean(attributes.getValue("isLocked"));
                Room otherRoom = castle.findRoomByName(attributes.getValue("other_room"));

                currentDoor = new Door(name, description, direction, isLocked);
                castle.addDoor(currentDoor);
                currentDoor.setRooms(prevRoom);
                currentDoor.setRooms(otherRoom);

                System.out.println("Name : " + name);
                System.out.println("Description : " + description);
                System.out.println("Direction : " + direction);
                System.out.println("isLocked : " + isLocked);
                System.out.println("Other_room : " + otherRoom);

            }

            if (qName.equals("item")) {
                String name = attributes.getValue("name");
                String description = attributes.getValue("description");
                double weight = Double.parseDouble(attributes.getValue("weight"));
                Boolean carryable = Boolean.parseBoolean(attributes.getValue("carryable"));
                Boolean hidden = Boolean.parseBoolean(attributes.getValue("hidden"));

                currentItem = new Item(name, description, weight, carryable, hidden);
                castle.addItem(currentItem);

                System.out.println("Name : " + name);
                System.out.println("Description : " + description);
                System.out.println("Weight : " + weight);
                System.out.println("Carryable : " + carryable);
                System.out.println("Hidden : " + hidden);

            }

           if (qName.equals("player")) {
               String name = attributes.getValue("name");
               String description = attributes.getValue("description");

               currentPlayer = new Player(name, description);
               castle.addCharacter(currentPlayer);

               System.out.println("Name : " + name);
               System.out.println("Description : " + description);

           }

           if (qName.equals("maid")) {
               String name = attributes.getValue("name");
               String description = attributes.getValue("description");
               Boolean cleaning = Boolean.parseBoolean(attributes.getValue("cleaning"));

               currentMaid = new Maid(name, description, cleaning);
               castle.addCharacter(currentMaid);

               System.out.println("Name : " + name);
               System.out.println("Description : " + description);
               System.out.println("Cleaning : " + cleaning);
           }

           if (qName.equals("guard")) {
               String name = attributes.getValue("name");
               String description = attributes.getValue("description");
               Boolean sleeping = Boolean.parseBoolean(attributes.getValue("sleeping"));

               currentGuard = new Guard(name, description, sleeping);
               castle.addCharacter(currentGuard);

               System.out.println("Name : " + name);
               System.out.println("Description : " + description);
               System.out.println("Sleeping : " + sleeping);
           }

           if (qName.equals("key")) {
               String name = attributes.getValue("name");
               String description = attributes.getValue("description");
               double weight = Double.parseDouble(attributes.getValue("weight"));
               Boolean carryable = Boolean.parseBoolean(attributes.getValue("carryable"));
               Boolean hidden = Boolean.parseBoolean(attributes.getValue("hidden"));
               Key key = new Key(name,description,weight,carryable,hidden);
               String door = attributes.getValue("door");

               currentKey = new Key(name,description,weight,carryable,hidden);
               castle.addItem(key);

               System.out.println("Name : " + name);
               System.out.println("Description : " + description);
               System.out.println("Weight : " + weight);
               System.out.println("Carryable : " + carryable);
               System.out.println("Hidden : " + hidden);
               System.out.println("Door : " + door);
            }
        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            System.out.println("End: " + qName);
        }

        public void endDocument() throws SAXException {
            System.out.println("Document End");
        }
    }
