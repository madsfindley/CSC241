package CastleProject;

import CastleProject.Character;

public class Player extends Character {
    protected final String name;
    protected final String description;
    public Player(String name, String description) {
        super(name, description);
        this.name = name;
        this.description = description;
    }
    public String inspectString(){
        return name + description;
    }

    public String toString(){
        return "Player: " + name + "," + description;
    }
}
