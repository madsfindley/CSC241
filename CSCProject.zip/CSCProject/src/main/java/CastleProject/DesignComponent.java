package CastleProject;

public class DesignComponent {
    // First, create a Creature Class that extends the Character class and assigning the instance variables
//    Public Class Creature extends Character{
//    private boolean dangerous;
//    private int health;
//    private String powers;


    // instantiate variables
//    Public Creature (String name,String description){
//       super(name,description);
//       this.dangerous = dangerous;
//       this.health = 10;
//       this.powers = fire;
//    }


    // have setters and getters just in case to use later
//    Public boolean isDangerous(){
//        return dangerous;
//    }
//        public void setDangerous(boolean dangerous) {
//            this.dangerous = dangerous;
//        }
//        public int getHealth() {
//            return health;
//        }
//        public void setHealth(int health) {
//            this.health = health;
//        }
//        public String getPowers() {
//            return powers;
//        }
//        public void setPowers(String powers) {
//            this.powers = powers;
//        }

// in the room class we can add a addCreatures method\
//public void addCreature(Creature creature){
//  characters.add(creature);

// to add all creatures to random rooms we can add methods
// List<Creature> allCreatures = getAllCreatures();

// for (Creature creature : all Creatures){

// now we add the creatures to the random rooms

//    Room randomRoom = getRandomRoom(rooms){
//    randomRoom.addCreature(creature);

// now i add a method to get the random room

//private Room getRandomRoom(List<Room> rooms){
//  int random = (int)(Math.random() * room.size());
//  return rooms.get(random);
//}

// since we added a getRandomRoom method we have to add the
// getter for it and return the random room

}




