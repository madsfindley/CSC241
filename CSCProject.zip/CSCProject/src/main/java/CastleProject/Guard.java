package CastleProject;

public class Guard extends NPC {
    private Room room;
    private Boolean sleeping;

    public void setRoom(Room room) {
        this.room = room;
    }


    public Guard(String name, String description,Boolean sleeping) {
        super(name, description);
        this.sleeping = sleeping;
    }

    public String toString() {
        return "Guard: " ;
    }
}
