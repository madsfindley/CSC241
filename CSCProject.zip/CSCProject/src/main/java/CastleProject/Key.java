package CastleProject;

public class Key extends Item {
        private String DoorKeyName;
        private Door unlocksDoor;

        public Key(String name, String description, double weight, boolean carryable, boolean hidden){
            super(name,description,weight,carryable,hidden);
            this.DoorKeyName = DoorKeyName;

        }

        @Override
        public String inspectString() {
            return super.inspectString() + "\nDoorName: " + DoorKeyName;
        }

        public String toString(){
            return "Key: " + DoorKeyName;
        }
    }

