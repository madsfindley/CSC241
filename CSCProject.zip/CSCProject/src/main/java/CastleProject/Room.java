package CastleProject;

import java.util.ArrayList;

public class Room implements Inspectable {
    private final String name;
    private final String description;
    private double weight;
    private boolean carryable;
    private boolean hidden;
    private  ArrayList<Character> characters;
    private ArrayList<Item> items;
    private ArrayList<Door> doors;
    private Door northDoor;
    private Door eastDoor;
    private Door southDoor;
    private Door westDoor;

    public void setNorthDoor(Door door) {
        this.northDoor = door;
        if (door != null) {
            door.setRooms(this);
        }
    }

    public void setSouthDoor(Door door) {
        this.southDoor = door;
        if (door != null) {
            door.setRooms(this);
        }
    }

    public void setEastDoor(Door door) {
        this.eastDoor = door;
        if (door != null) {
            door.setRooms(this);
        }
    }

    public void setWestDoor(Door door) {
        this.westDoor = door;
        if (door != null) {
            door.setRooms(this);
        }
    }

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void addItem(Item item) {
        items.add(item);
    }
    public void addCharacter(Character c) {
        characters.add(c);
        c.setRoom(this);
    }

    public void addDoor(Door d){
        doors.add(d);
    }


    public String getName(){
        return name;
    }

    public String getDescription(){
        return description;
    }

    public String inspectString() {
        StringBuilder housing = new StringBuilder("Name: " + name + "-" + description + "\nCharacters: ");
        for (Character character : characters) {
            housing.append(character.inspectString()).append("\n");
        }
        appendDoorInfo(housing, northDoor);
        appendDoorInfo(housing, eastDoor);
        appendDoorInfo(housing, southDoor);
        appendDoorInfo(housing, westDoor);

        return housing.toString();
    }

    private void appendDoorInfo(StringBuilder housing, Door door) {
        if (door != null) {
            housing.append(door.inspectString()).append("\n");
        }
    }

    public String toString() {
        String names = "Room " + "name= " + name + "\n";
        names += "description= " + description + "\n";
        return names;
    }

    public void removeCharacter(Character character) {
    }
}



