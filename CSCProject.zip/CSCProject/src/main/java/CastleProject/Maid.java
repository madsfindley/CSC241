package CastleProject;

public class Maid extends NPC {
    private boolean cleaning;
    public Maid(String name, String description,Boolean cleaning) {
        super(name, description);
        this.cleaning = cleaning;
    }

    public String toString(){
        return "Maid: " + name + "," + description;
    }
}


