package xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class GraphMLHandler {
        // Store our data.
        private Graph g;
        public void startDocument() throws SAXException {
            System.out.println("Document Start");
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            System.out.println("Start: " + qName);
            if (qName.equals("graph")) {
                System.out.println("ID : " + attributes.getValue("id"));
                System.out.println("Edge Default : " + attributes.getValue("edgedefault"));
                g = new Graph(attributes.getValue("id"),
                        attributes.getValue("edgedefault"));
            }
            if (qName.equals("node")) {
                System.out.println("ID : " + attributes.getValue("id"));
                Node n = new Node(attributes.getValue("id"));
                g.addNode(n);
            }
            if (qName.equals("edge")) {
                String sourceId = attributes.getValue("source");
                String targetId = attributes.getValue("target");
                System.out.println("source : " + sourceId);
                System.out.println("target : " + targetId);
                Node n1 = g.getNodeById(sourceId);
                Node n2 = g.getNodeById(targetId);
                if (n1 == null){
                    throw new RuntimeException("Malformed XML file: Missing node with id" + sourceId);
                }
                if (n2 == null){
                    throw new RuntimeException("Malformed XML file: Missing node with id" + targetId);
                }
                Edge e = new Edge(n1,n2);
            }
        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            System.out.println("End: " + qName);
        }

        public void endDocument() throws SAXException {
            System.out.println("Document End");
            System.out.println("What we learned...");
            System.out.println(g);
        }
}
